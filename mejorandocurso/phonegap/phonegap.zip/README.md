## PhoneGap + jQuery Mobile - Adrián Catalán [@ykro] (http://twitter.com/ykro)
<br />


Puedes descargar todo el [contenido en .zip] (https://github.com/mejorandolaclase/MejorandoCurso/blob/master/DisenoDesarrolloWeb/PhoneGap/PhoneGap.zip?raw=true).

Desarrollo de una aplicación móvil integrando el API de instagram y utilizando jQuery Mobile.

Esta carpeta comprende el ejemplo y recomendamos mucho leer la explicación y conceptos dentro de la plataforma para entenderlo completamente.
