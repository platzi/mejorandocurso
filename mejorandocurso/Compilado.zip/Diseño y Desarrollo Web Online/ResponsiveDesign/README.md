## Clase de Responsive Design - Leonidas Esteban [@LeonidasEsteban] (http://twitter.com/LeonidasEsteban)
<br />


Puedes descargar todo el [contenido en .zip] (https://github.com/MejorandoLaClase/MejorandoCurso/blob/master/Dise%C3%B1o%20y%20Desarrollo%20Web%20Online/ResponsiveDesign/ResponsiveDesign.zip?raw=true).

En esta clase BONUS para los estudiantes, se mejoró el ejercicio de "Trollyota Corlola" de @freddier y se enfoco en Responsive Design.

Esta carpeta comprende el ejemplo y recomendamos mucho leer su tutorial dentro de la plataforma.
