## Trollyota Corlola - John Freddy Vega  [@freddier] (http://Www.twitter.com/freddier)
<br />


Puedes descargar todo el [contenido en .zip] (https://github.com/MejorandoLaClase/Material/blob/master/Dise%C3%B1oDesarrolloWeb2013/TrollyotaCorlola/TrollyotaCorlola.zip?raw=true).

Desarrollo de un sitio web involucrando el diseño de un auto, utilizando tecnologías de parte de lado del cliente. Entre ellas:
- HTML5
- CSS3
- jQuery
