## Loltroen Delolrean - John Freddy Vega  [@freddier] (http://Www.twitter.com/freddier)
<br />


Puedes descargar todo el [contenido en .zip] (https://github.com/MejorandoLaClase/MejorandoCurso/blob/master/Dise%C3%B1o%20y%20Desarrollo%20Web%20Online/LoltroenDelolrean/LoltroenDelolrean.zip?raw=true).

Desarrollo de un sitio web involucrando el diseño de un auto, utilizando tecnologías de parte de lado del cliente. Entre ellas:
- HTML5
- CSS3
- jQuery
