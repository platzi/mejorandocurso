## Curso de Diseño y Desarrollo Web 2013
<br />
<br />
![Mejorandola](http://miguelnieva.com/img/cursodiseno.jpg)
<br />
<br />
<br />
<br />
Puedes descargar todo el [contenido en .zip] (https://github.com/MejorandoLaClase/MejorandoCurso/blob/master/Dise%C3%B1o%20y%20Desarrollo%20Web%20Online/TrollyotaCorlola/TrollyotaCorlola.zip?raw=true).

Los temas desarrollados en el curso abarcaron:

- HTML5
- CSS3
- Javascript
- NodeJS
- Python + Django
- PhoneGap + jQuery Mobile


