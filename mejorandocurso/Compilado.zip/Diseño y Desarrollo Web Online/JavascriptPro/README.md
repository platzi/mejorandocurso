## Javascript Profesional - Pablo Rigazzi [@prigazzi] (http://www.twitter.com/prigazzi)
<br />


Puedes descargar todo el [contenido en .zip] (https://github.com/MejorandoLaClase/MejorandoCurso/blob/master/Dise%C3%B1o%20y%20Desarrollo%20Web%20Online/JavascriptPro/JavascriptPro.zip?raw=true).

Esta fue una clase BONUS para los estudiantes donde se abarcaron temas de Javascript. Entre ellos:

- Closures
- Orientación a Objetos

Esta carpeta comprende el ejemplo y recomendamos mucho leer su tutorial dentro de la plataforma.
