## Python + Django - Arturo Jamaica [@ajamaica] (http://www.twitter.com/ajamaica)
<br />


Puedes descargar todo el [contenido en .zip] (https://github.com/MejorandoLaClase/MejorandoCurso/blob/master/Dise%C3%B1o%20y%20Desarrollo%20Web%20Online/Python/Python.zip?raw=true).

Desarrollo de una aplicación web utilizando el frameworkd "Django" con el lenguaje de programación "Python".

Esta carpeta comprende el ejemplo y recomendamos mucho leer su tutorial dentro de la plataforma.

