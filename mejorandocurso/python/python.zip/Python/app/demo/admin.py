from django.contrib import admin
from demo.models import *

admin.site.register(Libro)
admin.site.register(Autor)