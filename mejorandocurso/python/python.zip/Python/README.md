## Clase de Python + Django - Arturo Jamaica @ajamaica

Desarrollo de una aplicación web utilizando el frameworkd "Django" con el lenguaje de programación "Python".
