//
//  BalloonGame.h
//  demo_004_1
//
//  Created by Afrael Ortiz on 10/13/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Constants.h"
#import "BalloonGameBackgroundLayer.h"
#import "BalloonGameInteractiveLayer.h"

@interface BalloonGame : CCScene {
    
}

+(CCScene *)scene;

@end
