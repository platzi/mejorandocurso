//
//  MainMenu.h
//  demo_004_1
//
//  Created by Afrael Ortiz on 10/19/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Constants.h"
#import "MainMenuBackgroundLayer.h"
#import "MainMenuInteractiveLayer.h"

@interface MainMenu : CCScene {
    
}

+(CCScene *)scene;

@end
