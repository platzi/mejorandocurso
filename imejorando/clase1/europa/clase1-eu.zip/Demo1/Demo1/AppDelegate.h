//
//  AppDelegate.h
//  Demo1
//
//  Created by Raquel Hernandez on 10/14/13.
//  Copyright (c) 2013 Raquel Hernandez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
