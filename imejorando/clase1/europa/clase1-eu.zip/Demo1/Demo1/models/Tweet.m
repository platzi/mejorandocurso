//
//  Tweet.m
//  Demo1
//
//  Created by Raquel Hernandez on 10/14/13.
//  Copyright (c) 2013 Raquel Hernandez. All rights reserved.
//

#import "Tweet.h"

@implementation Tweet

- (NSInteger)numberoOfCharacters{
    return self.tweetBody.length;
}
@end
