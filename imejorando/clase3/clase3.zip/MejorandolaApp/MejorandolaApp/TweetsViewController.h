//
//  TweetsViewController.h
//  MejorandolaApp
//
//  Created by Raquel Hernandez on 10/17/13.
//  Copyright (c) 2013 Raquel Hernandez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Accounts/Accounts.h>
#import <Social/Social.h>

@interface TweetsViewController : UITableViewController<NSURLConnectionDelegate>
@property (nonatomic, strong) NSString *hashTag;
@property (nonatomic, strong) NSMutableArray* results;
@property (nonatomic, strong) ACAccountStore* accountStore;
@property (nonatomic, strong) NSURLConnection* connection;
@property (nonatomic, strong) NSMutableData* requestData;
@property (nonatomic, strong) NSURL* apiURL;
- (BOOL) userHasAccessToTwitter;

@end
