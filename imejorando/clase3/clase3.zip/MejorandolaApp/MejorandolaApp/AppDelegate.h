//
//  AppDelegate.h
//  MejorandolaApp
//
//  Created by Raquel Hernandez on 10/17/13.
//  Copyright (c) 2013 Raquel Hernandez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
