//
//  TweetsViewController.m
//  MejorandolaApp
//
//  Created by Raquel Hernandez on 10/17/13.
//  Copyright (c) 2013 Raquel Hernandez. All rights reserved.
//

#import "TweetsViewController.h"
#import <Accounts/Accounts.h>
#import <Social/Social.h>

@interface TweetsViewController ()
    @property (strong, nonatomic) NSURLSessionConfiguration *sessionConfiguration;
    @property (strong, nonatomic) NSURLSession *session;
@end

@implementation TweetsViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
     NSLog(@"%@",self.hashTag);
    
    self.apiURL = [NSURL URLWithString:@"https://api.twitter.com/1.1/"];
    self.accountStore = [[ACAccountStore alloc]init];
    if (![self userHasAccessToTwitter]) {
        NSLog(@"No twitter, agrega un alert aquí y notifica al usuario");
    }
    else{
        
        NSLog(@"We have twitter");
        ACAccountType *twitterAccountType = [self.accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
        
         [self.accountStore requestAccessToAccountsWithType:twitterAccountType options:NULL completion:^(BOOL granted, NSError *error) {
             
             NSDictionary *params = @{@"q": self.hashTag};
             
             SLRequest *request =[SLRequest requestForServiceType:SLServiceTypeTwitter requestMethod:SLRequestMethodGET URL:[self.apiURL URLByAppendingPathComponent:@"search/tweets.json"] parameters:params];
             
             NSArray *twitterAccounts = [self.accountStore accountsWithAccountType:twitterAccountType];
             request.account = twitterAccounts.lastObject;
             
             dispatch_async(dispatch_get_main_queue(), ^{
                 self.connection = [[NSURLConnection alloc] initWithRequest:[request preparedURLRequest] delegate:self];
                 [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
                 
             });
             
             
             
             
          }];
        
    
    }

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)userHasAccessToTwitter
{
    return [SLComposeViewController isAvailableForServiceType:SLServiceTypeTwitter];
}

/******************************
 * The NSURLConnection delegates.
 * These are responsible for recieving data from twitter.
 * When we recieve the initial connection data, we initialize requestData.
 * Each subsequent time we recieve data, we append that with the new data.
 * Once we've recieved all of the data, we propagate the array of tweet information.
 * If the connection fails before we completely recieve all of the data for whatever reason, we wipe out any data we recieved previously.
 * These are all defined in the NSURLConnectionDelegate protocol, and implemented here.
 ******************************/

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
//Implementar
    self.requestData = [NSMutableData data];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
//Implementa
    [[self requestData] appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
//Implementar
    
     if (self.requestData) {
         NSError *jsonError;
         NSDictionary* dictionary = [NSJSONSerialization JSONObjectWithData:self.requestData options: NSJSONReadingAllowFragments error:&jsonError];
         
         self.results = dictionary[@"statuses"];
         
         
     }
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    self.requestData = nil;
    [self.refreshControl endRefreshing];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
    
    
    
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    self.connection = nil;
    self.requestData = nil;
    [self.refreshControl endRefreshing];
    
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });

}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [self.results count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"tweetCell" forIndexPath:indexPath];
    
    // Each element of the results array is a dictionary.
    // This gives us a lot of information about the tweet, such as the user's display name, the tweet's data, and the user's profile picture.
    // All pretty useful stuff.
    //NSLog(@"%@",self.results);
    NSDictionary *tweet = (self.results)[indexPath.row];
    
    
    UILabel* label = (UILabel*)[cell viewWithTag:1];
    label.text = [NSString stringWithFormat:@"@%@", tweet[@"user"][@"screen_name"]];
    UILabel* tweetLabel = (UILabel*)[cell viewWithTag:2];
    tweetLabel.text =tweet[@"text"];
    
    // We may get a lot of images at once, so it's best to leverage GCD to asynchronously pull in profile images.
    // La siguiente es una técnica, es su tarea tratar de mejorarla
    // La idea es que las imagenes se queden en cache y no tener
    // Que estar cambiandolas cada vez que se hace scroll
    // Hacemos el request y le damos la prioridad 0
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        NSURL *profileImageURL = [NSURL URLWithString:(tweet[@"user"])[@"profile_image_url"]];
        
        UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:profileImageURL]];
        // Luego en otro dispatch vámos a setear la imagen
        dispatch_async(dispatch_get_main_queue(), ^{
            UIImageView *imageView = (UIImageView*)[cell viewWithTag:3];
            imageView.image = image;
            
        });
    });
  
    
    // Configure the cell...
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a story board-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

 */

@end
