<?php

class Candidate extends \Eloquent {
	protected $fillable = [];
}