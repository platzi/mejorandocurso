<?php

class Category extends \Eloquent {
	protected $fillable = [];
}