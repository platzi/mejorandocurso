<!DOCTYPE html>
<html>
<head>
    <title><?= $titulo ?></title>
</head>
<body>
<h1><?= $titulo ?></h1>
Aprendiendo <strong><?= $language ?></strong>

<p><a href="contactos">Contactanos</a></p>

</body>
</html>