<?php

    $confidencial = "wow such private very confidential";
    $language = "PHP";
    $titulo = 'MejorandoPHP';

    // llamando una funcion
    view('home', compact('language', 'titulo'));

