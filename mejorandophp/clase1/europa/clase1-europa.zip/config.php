<?php

/*
 * Mostramos los errores
 * en modo de desarrollo
 */
ini_set('display_errors', true);
error_reporting(E_ALL);