<?php

require 'config.php';
require 'helpers.php';

controller($_GET['url']);
