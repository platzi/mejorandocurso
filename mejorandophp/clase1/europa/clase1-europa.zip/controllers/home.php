<?php

    $saludo = "Aprende PHP con nosotros";
    $titulo = "Curso de mejorando.la";

    $confidencial = "such private, wow";

    // Llama a a funcion
    view('home', compact('saludo', 'titulo'));

?>