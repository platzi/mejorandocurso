<?php

// Llama a a funcion
view('contactos');