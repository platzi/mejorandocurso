<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<h1><?= $titulo ?></h1>

<strong><?= $saludo ?></strong>

<p><a href="contactos">Contactanos</a></p>

</body>
</html>