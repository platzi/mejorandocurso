<?php

class ContactosController {

    public function indexAction()
    {
        return new View('contactos');
    }

}