<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

    <h4>MejorandoPHP</h4>

    <?= $tpl_content ?>

    <hr>

    <p>Copyright whatever whatever</p>

</body>
</html>