<?php

abstract class Response {

    abstract public function execute();

}