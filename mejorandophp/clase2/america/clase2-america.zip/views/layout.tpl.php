<!DOCTYPE html>
<html>
<head>
    <title>MejorandoPHP</title>
</head>
<body>
<h1>MejorandoPHP</h1>

<?= $tpl_content; ?>

<hr>

Copyright, ponies

</body>
</html>