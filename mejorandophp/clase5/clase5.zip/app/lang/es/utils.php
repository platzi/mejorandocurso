<?php

return [
    'job_types' => [
        'full'      => 'Tiempo completo',
        'partial'   => 'Tiempo parcial',
        'freelance' => 'Freelance'
    ]
];