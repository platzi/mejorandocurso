var a = 2
var b = 3
var c = a + b
console.log(c)		// 5