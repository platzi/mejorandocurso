function max(a,b){
	if(a>b){
		return a
	}
	return b
}
alert(max(2,3)) // 3

