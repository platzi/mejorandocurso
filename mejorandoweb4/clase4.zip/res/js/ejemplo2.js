var a = 2,
	b = 3,
	max

if( a > b ){
	max = a
}else{
	max = b
}
alert( max ) // 3

