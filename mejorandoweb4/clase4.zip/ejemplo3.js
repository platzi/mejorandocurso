function max(a,b){
	if(a>b){
		console.log('este si va a salir')
		return a
		console.log('esto no va a salir')
	}
	return b
}
alert(max(6,3)) // 3

