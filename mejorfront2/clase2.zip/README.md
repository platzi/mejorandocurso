![Mejorandola](http://miguelnieva.com/img/frontend.jpg)
<br />
<br />
##   Desarrollo de la interfaz y funcionalidad de nuestra app Puls3 - [@freddier] (http://www.twitter.com/freddier)
<br />
<br />
Puedes descargar todo el [contenido en .zip] (https://github.com/mejorandolaclase/MejorandoCurso/blob/master/Frontend/Clase2/Clase2.zip?raw=true).


