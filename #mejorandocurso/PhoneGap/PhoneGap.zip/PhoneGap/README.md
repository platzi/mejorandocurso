## Clase de PhoneGap - Adrián Catalán @ykro

Desarrollo de una aplicación móvile integrando el API de instagram y utilizando jQuery Mobile.
