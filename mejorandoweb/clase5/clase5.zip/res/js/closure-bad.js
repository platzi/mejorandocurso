var a = 3
var b = 2

function miFuncion(c){
	return c + a + b
}