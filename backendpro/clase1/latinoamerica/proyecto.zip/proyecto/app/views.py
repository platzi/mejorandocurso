# Create your views here.
from django.http import HttpResponse

def home(request):
    return HttpResponse("Pantalla de Index")

def home2(request):
    return HttpResponse("Este es otro HOME")
    
def home3(request):
    return HttpResponse("Este es as HOME 333")
    
def post(request,id_post):
    return HttpResponse("Este es el post %s" % id_post)

def live(request,id1,id2):
    return HttpResponse("reproduciendo %s y %s" % (id1,id2))
    
def request(request):
    return HttpResponse("Datos de Request %s" % request)
    