# Create your views here.
from django.http import HttpResponse
import urllib2
import json

def home(request):
    try:
        f = urllib2.urlopen("http://congresorest.appspot.com/diputado/3")
        g =  f.read()
        f.close()
    except HTTPError, e:
        print "Error!!"
        print e.code

    except URLError, e:
        print "Error!!"
        print e.code
    dictionario = json.loads(g)
    return HttpResponse(dictionario["entidad"])
    

def home2(request):
    
    
    return HttpResponse("Este es otro HOME")
    
def home3(request):
    
    
    return HttpResponse("Este es as HOME 333")
    
def post(request,id_post):
    if int(id_post) > 10 :
        return HttpResponse("Este es mayor que 10 : %s" % id_post)
    else:
        return HttpResponse("Este es menor que 10 : %s" % id_post)

def live(request,id1,id2):
    return HttpResponse("reproduciendo %s y %s" % (id1,id2))
    
def request(request):
    return HttpResponse("Datos de Request %s" % request)
    