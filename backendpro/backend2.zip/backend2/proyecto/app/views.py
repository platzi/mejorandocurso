# Create your views here.
from django.http import HttpResponse

def home(request):
    return HttpResponse("Hola Que hacen")
    
def post(request,digit):
    if(int(digit) < 10):
        return HttpResponse("Este es un digito : %i" % int(digit))
    else:
        return HttpResponse("Este es mayor a 10 :  %i" % int(digit))