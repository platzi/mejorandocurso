var express = require('express');
var server = express();

server.listen(3000);