from django.shortcuts import render_to_response,get_object_or_404
from django.template.context import RequestContext
from models import *
from django.http import HttpResponse

def home(request):
    categorias = Categoria.objects.all()
    enlaces = Enlace.objects.all()
    template = "index.html"
    return render_to_response(template,{"categorias" : categorias, "enlaces":enlaces})

def categoria(request,id_categoria):
    categorias = Categoria.objects.all()
    cat = get_object_or_404(Categoria,pk = id_categoria)
    #cat = Categoria.objects.get(pk = id_categoria)
    enlaces = Enlace.objects.filter(categoria = cat)
    template = "index.html"
    return render_to_response(template,locals())

def minus(request,enlace_id):
    return HttpResponse("")
    
def plus(request,enlace_id):
    return HttpResponse("")
    
def add(request):
    return HttpResponse("")

    