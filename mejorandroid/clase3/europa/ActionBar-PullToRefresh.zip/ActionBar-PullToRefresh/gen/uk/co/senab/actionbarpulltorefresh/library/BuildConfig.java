/** Automatically generated file. DO NOT MODIFY */
package uk.co.senab.actionbarpulltorefresh.library;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}