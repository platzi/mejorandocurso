package com.mejorandola.ejemplo;

import uk.co.senab.actionbarpulltorefresh.library.PullToRefreshAttacher;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;

import com.mejorandola.ejemplo.data.CustomPagerAdapter;

public class MainActivity extends
		FragmentActivity {
	private ViewPager view_pager;
	private CustomPagerAdapter adapter;
	private PullToRefreshAttacher pull_to_refresh_attacher;
	
	@Override
	protected void onCreate(
			Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		pull_to_refresh_attacher = PullToRefreshAttacher.get(this);
		
		adapter = new CustomPagerAdapter(getSupportFragmentManager());
		view_pager = (ViewPager)findViewById(R.id.pager);
		view_pager.setAdapter(adapter);
		
	}

	public PullToRefreshAttacher getAttacher() {
		return pull_to_refresh_attacher;
	}

}
