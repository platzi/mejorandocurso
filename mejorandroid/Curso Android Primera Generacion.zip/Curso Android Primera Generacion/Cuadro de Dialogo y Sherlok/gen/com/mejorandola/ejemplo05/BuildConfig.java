/** Automatically generated file. DO NOT MODIFY */
package com.mejorandola.ejemplo05;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}