## Clase de NodeJS - Daniel Zavala @siedrix

Es importante leer los siguientes contenidos dentro de la plataforma:

- Pasando de PHP a NodeJS
- Instalación de NodeJS
