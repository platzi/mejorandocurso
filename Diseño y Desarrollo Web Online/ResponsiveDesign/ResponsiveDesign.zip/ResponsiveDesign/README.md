## Clase de Responsive Design - Leonidas Esteban @LeonidasEsteban

Transformamos el ejercicio de "Trollyota Corlola" de @freddier en Responsive Design.
