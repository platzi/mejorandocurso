puls3
=====

web app de la clase profesional de front-end de mejorando.la

Install

	npm install 

Run server

	supervisor server

### Interesting links

[Backbone](backbonejs.org)
[Tutorial de backbone](https://github.com/addyosmani/backbone-fundamentals/blob/gh-pages/backbone-fundamentals.md)
[Backbone generate](https://github.com/posabsolute/backbone_generate)
[Grunt.js](http://gruntjs.com/getting-started)
