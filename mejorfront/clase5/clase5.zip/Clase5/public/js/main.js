$(document).ready(function(){
	console.log('Starting app');
});
