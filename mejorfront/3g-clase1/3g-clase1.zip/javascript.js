$(document).ready(function(){
	// Javascript en un archivo
	console.log('Esto es javascript en un archivo local');
});